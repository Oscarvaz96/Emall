# Errors

When you configuring acl roles please remember to add **System > Other Settings > Notifications** 
resources to avoid any errors on dashboard.

https://github.com/magento/magento2/issues/10071