var config = {
    map: {
        '*': {
            categoryTree: 'Cminds_AdvancedPermissions/js/category-tree'
        }
    }
};
